let os = require("node:os");
let path = require("node:path");
let moment = require("moment");

console.log(moment().format('MMMM Do YYYY, h:mm:ss a'));

console.log(os.platform());
console.log(os.totalmem()/1024/1024/1024);
console.log(os.freemem()/1024/1024/1024);
console.log(os.version());

console.log(path.parse("c:\Users\USER\Desktop\MERN-2411_Batch\Level-4\S71(Day-71)-Intro To Node.js\Node.js.zip"))
